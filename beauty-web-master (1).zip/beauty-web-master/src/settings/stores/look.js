import Store from "../../store.js"

export default Store.module("look", { texture: "" })

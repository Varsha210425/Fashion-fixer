import Store from "../../store.js"

export default Store.module("softlight", {
  title: "Softlight",
  strength: 0,
})

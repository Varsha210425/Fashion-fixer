import Store from "../../store.js"

export default Store.module("eyelashes", {
  title: "Eyelashes",
  color: "0.22 0.17 0.17 0.65",
  enabled: false,
})

import Store from "../../store.js"

export default Store.module("lut", { texture: "" })

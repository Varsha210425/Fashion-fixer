import Store from "../../store.js"

export default Store.module("brows", {
  title: "Brows",
  color: "0.172 0.125 0.105 0.732",
  enabled: false,
})

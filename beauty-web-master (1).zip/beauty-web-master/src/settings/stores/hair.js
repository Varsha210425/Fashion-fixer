import Store from "../../store.js"

export default Store.module("hair", {
  title: "Color",
  color: ["0.84 0.24 0.08 1"],
  enabled: false,
})

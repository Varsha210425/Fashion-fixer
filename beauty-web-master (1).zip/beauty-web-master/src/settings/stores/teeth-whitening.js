import Store from "../../store.js"

export default Store.module("teeth-whitening", {
  title: "Teeth whitening",
  strength: 0,
})
